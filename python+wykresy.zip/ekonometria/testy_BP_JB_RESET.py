import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan, het_goldfeldquandt
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.stats.outliers_influence import reset_ramsey
import matplotlib.pyplot as plt
from scipy.stats import shapiro, chisquare

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters1.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

#mumbo jumbo
crime_ratios_powiaty.iloc[:, 1] = crime_ratios_powiaty.iloc[:, 1] ** 2

# Przygotowanie zmiennych dla modelu OLS (dane z crime_ratios_srednie.xlsx)
y = crime_ratios_powiaty.iloc[:, 1]  # Druga kolumna jako zmienna zależna
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)  # Usunięcie kolumny 'Nazwa', bo to etykieta
X = sm.add_constant(X)  # Dodanie stałej do modelu

# Dopasowanie modelu
model = sm.OLS(y, X).fit()

# Test Breuscha-Pagana
bp_test = het_breuschpagan(model.resid, model.model.exog)
print("Breusch-Pagan Test:")
print("LM statistic:", bp_test[0])
print("LM p-value:", bp_test[1])
print("F statistic:", bp_test[2])
print("F p-value:", bp_test[3])
print("\n")

# Wykres wartości Cooka
influence = model.get_influence()
cooks_d, _ = influence.cooks_distance

plt.figure(figsize=(10, 6))
plt.stem(np.arange(len(cooks_d)), cooks_d, markerfmt=",", basefmt=" ")
plt.title("Wykres wartości Cooka")
plt.xlabel("Indeks obserwacji")
plt.ylabel("Cook's Distance")
plt.axhline(4 / len(cooks_d), color='red', linestyle='--', label="4/n próg")
plt.legend()
plt.show()

# Test i wykres normalności (Shapiro-Wilk)
shapiro_test_stat, shapiro_p_value = shapiro(model.resid)
print(f"Shapiro-Wilk Test:\nStatistic: {shapiro_test_stat:.4f}, p-value: {shapiro_p_value:.4e}")

plt.figure(figsize=(10, 6))
sm.qqplot(model.resid, line='45', fit=True)
plt.title("QQ-Plot: Analiza normalności (Sharpiro-Wilk)")
plt.show()

# Test RESET na formę funkcyjną
reset_test = reset_ramsey(model, degree=3)
print("RESET Test (forma funkcyjna):")
print(f"F statistic: {reset_test.fvalue:.4f}, p-value: {reset_test.pvalue:.4e}")
print("\n")

# Test Jacques-Bera
jb_test_stat, jb_p_value, _, _ = jarque_bera(model.resid)
print("Jacques-Bera Test:")
print(f"Statistic: {jb_test_stat:.4f}, p-value: {jb_p_value:.4e}")
print("\n")

# Test Durbina-Watsona
dw_stat = durbin_watson(model.resid)
print("Durbin-Watson Test:")
print(f"Statistic: {dw_stat:.4f}")
