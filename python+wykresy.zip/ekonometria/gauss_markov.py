import statsmodels.api as sm
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.stats.diagnostic import het_breuschpagan
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant
from scipy import stats

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie danych (przykład - wybór zmiennych do modelu)
X = dane_wejscia_powiaty[['średnia ludności na 1 km2', 'średnia liczba ludności w tysiącach',
                          'średnia liczba ludności w tysiącach mężczyźni', 'średnia ludność w tysiącach kobiety',
                          'średni wskaźnik urbanizacji w %', 'średnia liczba bezrobotnych osób']]
y = crime_ratios_powiaty['średnia liczba przestępstw ogółem']

# Dodanie stałej do zmiennych objaśniających
X = sm.add_constant(X)

# Dopasowanie modelu OLS (regresja liniowa)
model = sm.OLS(y, X).fit()

# Wyświetlenie wyników regresji
print(model.summary())

# --- Testowanie założeń regresji ---

# 1. Test Liniowości: Wykres reszt vs przewidywane wartości
y_pred = model.predict(X)
plt.scatter(y_pred, model.resid)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel('Predykcje')
plt.ylabel('Reszty')
plt.title('Wykres reszt vs. przewidywania')
plt.show()

# 2. Test Autokorelacji: Durbin-Watson
dw_stat = durbin_watson(model.resid)
print(f'Durbin-Watson Statistic: {dw_stat}')

# 3. Test Heteroskedastyczności: Breusch-Pagan
bp_test = het_breuschpagan(model.resid, X)
bp_test_stat, bp_test_pvalue, _, _ = bp_test
print(f'Breusch-Pagan p-value: {bp_test_pvalue}')

# 4. Test Wielokolinearności: VIF (Współczynniki wariancji inflacji)
X_with_const = add_constant(X)
vif_data = pd.DataFrame()
vif_data["feature"] = X_with_const.columns
vif_data["VIF"] = [variance_inflation_factor(X_with_const.values, i) for i in range(X_with_const.shape[1])]
print("Współczynniki VIF:")
print(vif_data)

# 5. Test Normalności: Jarque-Bera
jb_stat, jb_pvalue = stats.jarque_bera(model.resid)
print(f'Jarque-Bera p-value: {jb_pvalue}')
