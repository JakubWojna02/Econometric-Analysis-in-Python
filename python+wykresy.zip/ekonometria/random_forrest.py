import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Łączenie danych
dane = dane_wejscia.copy()
dane['średnia liczba przestępstw ogółem'] = crime_ratios['średnia liczba przestępstw ogółem']

# Wybór zmiennych niezależnych (X) oraz zmiennej zależnej (Y)
X = dane[['średnia ludności na 1 km2', 'średnia liczba ludności w tysiącach',
          'średnia liczba ludności w tysiącach mężczyźni', 'średnia ludność w tysiącach kobiety',
          'średni wskaźnik urbanizacji w %', 'średnia liczba bezrobotnych osób',
          'średnia liczba bezrobotnych mężczyzn', 'średnia liczba bezrobotnych kobiet',
          'średni dochód budżetu powiatów na mieszkańca', 'średnie dochody budżetów powiatu']]  # Zmienne niezależne
y = dane['średnia liczba przestępstw ogółem']  # Zmienna zależna

# Podział danych na zbiór treningowy i testowy
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Tworzenie modelu Random Forest
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# Predykcja na zbiorze testowym
y_pred = rf_model.predict(X_test)

# Obliczanie błędu średniokwadratowego
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error (MSE) for Random Forest: {mse:.4f}")

# Wykres ważności cech
importances = rf_model.feature_importances_
indices = np.argsort(importances)

plt.figure(figsize=(12, 8))
plt.title("Feature Importances", fontsize=16, weight='bold')
plt.barh(range(X.shape[1]), importances[indices], align="center", color='teal', alpha=0.7)
plt.yticks(range(X.shape[1]), [X.columns[i] for i in indices], fontsize=12)
plt.xlabel("Relative Importance", fontsize=14)
plt.gca().tick_params(axis='y', left=False)  # Remove y-axis ticks for aesthetic purposes
plt.gca().spines['top'].set_visible(False)  # Remove the top spine for cleaner look
plt.gca().spines['right'].set_visible(False)  # Remove the right spine for cleaner look
plt.gca().spines['left'].set_visible(False)  # Optional: remove left spine for a minimalistic look
plt.show()
