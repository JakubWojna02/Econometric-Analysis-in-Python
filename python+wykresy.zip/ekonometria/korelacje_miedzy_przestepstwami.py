import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.colors as colors

def analyze_crime_correlations(file_path):
    # Wczytaj dane
    df = pd.read_excel(file_path)

    # Filtruj tylko dane dotyczące powiatów (założenie: w kolumnie 'Nazwa' występuje 'Powiat')
    df_powiaty = df[df['Nazwa'].str.contains('Powiat', case=True)]

    # Kolumny zawierające dane o przestępstwach
    crime_columns = [
        'średnia liczba przestępstw ogółem',
        'średnia liczba przestępstw o charakterze kryminalnym',
        'średnia liczba przestępstw o charakterze gospodarczym',
        'średnia liczba przestępstw przeciwko bezpieczeństwu powszechnemu i bezpieczeństwu w komunikacji - drogowe',
        'średnia liczba przestępstw przeciwko życiu i zdrowiu',
        'średnia liczba przestępstw przeciwko mieniu',
        'średnia liczba przestępstw przeciwko wolności, wolności sumienia, wolności seksualnej i obyczajności razem',
        'średnia liczba przestępstw przeciwko rodzinie i opiece',
        'średnia liczba przestępstw przeciwko bezpieczeństwu powszechnemu i bezpieczeństwu w komunikacji razem'
    ]

    # Przygotuj krótsze nazwy dla etykiet
    label_mapping = {
        'średnia liczba przestępstw ogółem': 'Ogółem',
        'średnia liczba przestępstw o charakterze kryminalnym': 'Kryminalne',
        'średnia liczba przestępstw o charakterze gospodarczym': 'Gospodarcze',
        'średnia liczba przestępstw przeciwko bezpieczeństwu powszechnemu i bezpieczeństwu w komunikacji - drogowe': 'Drogowe',
        'średnia liczba przestępstw przeciwko życiu i zdrowiu': 'Przeciwko życiu',
        'średnia liczba przestępstw przeciwko mieniu': 'Przeciwko mieniu',
        'średnia liczba przestępstw przeciwko wolności, wolności sumienia, wolności seksualnej i obyczajności razem': 'Przeciwko wolności',
        'średnia liczba przestępstw przeciwko rodzinie i opiece': 'Przeciwko rodzinie',
        'średnia liczba przestępstw przeciwko bezpieczeństwu powszechnemu i bezpieczeństwu w komunikacji razem': 'Bezpieczeństwo razem'
    }

    # Wybierz dane do analizy korelacji tylko dla powiatów
    crime_data = df_powiaty[crime_columns]

    # Oblicz macierz korelacji
    correlation_matrix = crime_data.corr()

    # Zmień nazwy kolumn i indeksów na krótsze
    correlation_matrix.columns = [label_mapping[col] for col in correlation_matrix.columns]
    correlation_matrix.index = [label_mapping[idx] for idx in correlation_matrix.index]

    # Ustawienia dla polskich znaków
    plt.rcParams['font.family'] = 'DejaVu Sans'

    # Stwórz własną mapę kolorów w odcieniach od białego (0) do ciemno-bordowego (1)
    red_cmap = colors.LinearSegmentedColormap.from_list("", ["white", "darkred"])

    # Stwórz wykres
    plt.figure(figsize=(14, 10))  # Zmiana rozmiaru wykresu
    sns.set_style('whitegrid')  # Ustawienie stylu wykresu

    # Tworzenie heatmapy z mapą kolorów
    sns.heatmap(correlation_matrix,
                annot=True,
                cmap=red_cmap,  # Użyj mapy kolorów od białego do ciemno-bordowego
                vmin=0, vmax=1,  # Skala wartości korelacji od 0 do 1
                fmt='.2f',  # Wyświetlanie wartości korelacji z dwoma miejscami po przecinku
                annot_kws={"size": 10, "color": "black"},  # Styl wartości na wykresie
                linewidths=2.0,  # Grubsze linie podziału
                linecolor='black',  # Kolor linii
                square=True)  # Kwadratowy układ

    # Dodaj tytuł i etykiety
    plt.title('Macierz korelacji między rodzajami przestępstw', fontsize=16, weight='bold')  # Większy i pogrubiony tytuł
    plt.xlabel('Rodzaje przestępstw oś X', fontsize=15)  # Etykieta osi X
    plt.ylabel('Rodzaje przestępstw oś Y', fontsize=15)  # Etykieta osi Y
    plt.xticks(rotation=45, ha='right', fontsize=10)  # Obrócone i mniejsze etykiety osi X
    plt.yticks(fontsize=10)  # Mniejsze etykiety osi Y
    plt.tight_layout()  # Automatyczne dopasowanie elementów wykresu

    # Pokaż wykres
    plt.show()

# Wykonaj analizę
correlation_results = analyze_crime_correlations('crime_ratios_srednie.xlsx')
