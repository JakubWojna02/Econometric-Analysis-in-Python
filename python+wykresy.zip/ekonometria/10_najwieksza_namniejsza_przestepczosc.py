import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# polskie zanki
plt.rcParams['font.family'] = 'DejaVu Sans'


def analyze_crime_data(file_path):
    # wczytuje excel
    df = pd.read_excel(file_path)

    # filtruj tylko powiaty?
    powiaty_df = df[df['Nazwa'].str.contains('Powiat', case=True, na=False)]

    # znajdź top 10 i bottom 10 powiatów
    top_10 = powiaty_df.nlargest(10, 'średnia liczba przestępstw ogółem')
    bottom_10 = powiaty_df.nsmallest(10, 'średnia liczba przestępstw ogółem')

    # Utwórz DataFrame z wynikami
    def create_result_df(df, category):
        result = df[['Nazwa', 'średnia liczba przestępstw ogółem']].copy()
        result['Kategoria'] = category
        result['średnia liczba przestępstw ogółem'] = result['średnia liczba przestępstw ogółem'].round(1)
        return result

    top_10_df = create_result_df(top_10, 'Najwyższa przestępczość')
    bottom_10_df = create_result_df(bottom_10, 'Najniższa przestępczość')

    # Połącz wyniki
    results = pd.concat([top_10_df, bottom_10_df])

    return results


# Wykonaj analizę
results = analyze_crime_data('crime_ratios_srednie.xlsx')

# Zapisz wyniki do pliku Excel
results.to_excel('analiza_przestepczosci.xlsx', index=False)

print("Wyniki analizy zostały zapisane do pliku 'analiza_przestepczosci.xlsx'")

# Wizualizacja danych
plt.figure(figsize=(15, 6))
sns.barplot(data=results[results['Kategoria'] == 'Najwyższa przestępczość'],
            x='Nazwa', y='średnia liczba przestępstw ogółem')
plt.xticks(rotation=45, ha='right')
plt.title('Top 10 powiatów z najwyższą przestępczością')
plt.tight_layout()
plt.show()

plt.figure(figsize=(15, 6))
sns.barplot(data=results[results['Kategoria'] == 'Najniższa przestępczość'],
            x='Nazwa', y='średnia liczba przestępstw ogółem')
plt.xticks(rotation=45, ha='right')
plt.title('Top 10 powiatów z najniższą przestępczością')
plt.tight_layout()
plt.show()