import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

data = pd.merge(dane_wejscia_powiaty, crime_ratios_powiaty, on='Nazwa', how='inner')

X = data['średnia ludności na 1 km2'].values.reshape(-1, 1)
y = data['średnia liczba przestępstw ogółem'].values.reshape(-1, 1)

scaler_X = StandardScaler()
scaler_y = StandardScaler()

X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y)

X_scaled = sm.add_constant(X_scaled)

model = sm.OLS(y_scaled, X_scaled).fit()

print(model.summary())

plt.scatter(X_scaled[:, 1], y_scaled, color='blue', label='Dane')
plt.plot(X_scaled[:, 1], model.predict(X_scaled), color='red', label='Linia regresji')
plt.xlabel('Średnia ludności na 1 km² (standardyzowane)')
plt.ylabel('Średnia liczba przestępstw ogółem (standardyzowane)')
plt.title('Analiza regresji (dane standardyzowane)')
plt.legend()
plt.show()

import os
print(os.listdir())

#Podsumowanie:
#ałożenie 1 (Liniowość): ok
#Założenie 2 (Brak autokorelacji): ok (Durbin-Watson = 2.121).
#Założenie 3 (Homoskedastyczność): chyba tez okej
#Założenie 4 (Brak współliniowości): ok, mamy tylko jedna zmienna
#Założenie 5 (Normalność rozkładu reszt): nie okej, reszty nie maja rozkladu normalnego, moze GLM?
#Założenie 6 (Brak zmienności w czasie): ok, mam dane przekrojowe

