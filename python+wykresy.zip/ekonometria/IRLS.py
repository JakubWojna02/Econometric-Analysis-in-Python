import pandas as pd
import numpy as np
import statsmodels.api as sm

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Łączenie danych
dane = dane_wejscia.copy()
dane['średnia liczba przestępstw ogółem'] = crime_ratios['średnia liczba przestępstw ogółem']

# Wybór zmiennych niezależnych (X) oraz zmiennej zależnej (Y)
X = dane[['średnia ludności na 1 km2', 'średnia liczba ludności w tysiącach',
          'średnia liczba ludności w tysiącach mężczyźni', 'średnia ludność w tysiącach kobiety',
          'średni wskaźnik urbanizacji w %', 'średnia liczba bezrobotnych osób',
          'średnia liczba bezrobotnych mężczyzn', 'średnia liczba bezrobotnych kobiet',
          'średni dochód budżetu powiatów na mieszkańca', 'średnie dochody budżetów powiatu']]  # Zmienne niezależne
y = dane['średnia liczba przestępstw ogółem']  # Zmienna zależna

# Dodajemy wyraz wolny (stałą)
X = sm.add_constant(X)

# Regresja IRLS - Iteratively Reweighted Least Squares
# Przygotowanie modelu
irls_model = sm.WLS(y, X, weights=1/np.sqrt(y))  # Użycie wag odwrotności pierwiastka z y jako przykład
irls_result = irls_model.fit()

# Wyświetlenie wyników modelu
print(irls_result.summary())
