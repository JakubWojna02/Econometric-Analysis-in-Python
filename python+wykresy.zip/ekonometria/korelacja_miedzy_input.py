# Correcting the column names and recalculating the correlation matrix
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the data from the Excel file
FILEPATH = 'input_parameters.xlsx'
df = pd.read_excel(FILEPATH, sheet_name='TABLICA')

# Corrected list of relevant columns for correlation analysis
correlation_columns = [
    'Nazwa',
    'średnia ludności na 1 km2',
    'średnia liczba ludności w tysiącach',
    'średnia liczba ludności w tysiącach mężczyźni',
    'średnia ludność w tysiącach kobiety',
    'średni wskaźnik urbanizacji w %',
    'średnia liczba bezrobotnych osób',
    'średnia liczba bezrobotnych mężczyzn',
    'średnia liczba bezrobotnych kobiet',
    'średni dochód budżetu powiatów na mieszkańca',
    'średnie dochody budżetów powiatu'
]

# Filter the dataframe to include only the selected columns
filtered_df = df[correlation_columns].select_dtypes(include=['float64', 'int64'])

# Calculate the correlation matrix
correlation_matrix = filtered_df.corr()

# Create a heatmap for visualization
plt.figure(figsize=(12, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Macierz korelacji wskaźników demograficznych i ekonomicznych', fontsize=16)
plt.show()

# Display the correlation matrix
print(correlation_matrix)