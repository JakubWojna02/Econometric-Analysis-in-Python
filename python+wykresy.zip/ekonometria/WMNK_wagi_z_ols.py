import pandas as pd
import statsmodels.api as sm

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie zmiennych dla modelu
y = crime_ratios_powiaty.iloc[:, 1]  # Zmienna zależna
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)  # Usunięcie kolumny 'Nazwa'
X = sm.add_constant(X)  # Dodanie stałej do modelu

# Krok 1: Dopasowanie modelu OLS w celu oszacowania błędów resztowych
model_ols = sm.OLS(y, X).fit()

# Krok 2: Obliczenie kwadratów reszt jako oszacowanie wariancji błędu
residuals = model_ols.resid
variance_estimation = residuals**2

# Krok 3: Utworzenie wag jako odwrotności oszacowanej wariancji błędu
weights = 1 / (variance_estimation + 1e-5)  # Dodanie małej wartości, aby uniknąć dzielenia przez 0

# Krok 4: Dopasowanie modelu WMNK z użyciem obliczonych wag
model_wls = sm.WLS(y, X, weights=weights).fit()

# Wyświetlenie podsumowania modelu
print(model_wls.summary())
