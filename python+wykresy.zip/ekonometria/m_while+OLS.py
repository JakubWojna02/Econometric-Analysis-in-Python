import pandas as pd
import statsmodels.api as sm

# Wczytanie danych z pliku
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie danych do regresji
# Zmienna zależna
y = crime_ratios_powiaty['średnia liczba przestępstw ogółem']

# Zmienne objaśniające
X = dane_wejscia_powiaty[['średnia ludności na 1 km2', 'średnia liczba ludności w tysiącach',
                          'średnia liczba ludności w tysiącach mężczyźni', 'średnia ludność w tysiącach kobiety',
                          'średni wskaźnik urbanizacji w %', 'średnia liczba bezrobotnych osób']]

# Dodanie stałej do modelu (intercept)
X = sm.add_constant(X)

# Tworzymy i dopasowujemy model OLS
model = sm.OLS(y, X)

# Dopasowanie modelu
results = model.fit()

# Wyświetlanie wyników bez poprawki na heteroskedastyczność
print("Wyniki OLS bez macierzy White'a:")
print(results.summary())

# Wyniki z błędami standardowymi skorygowanymi o heteroskedastyczność (macierz White'a)
robust_results = results.get_robustcov_results(cov_type='HC3')  # Używamy HC3 dla bardziej konserwatywnej korekty

# Wyświetlanie wyników z błędami skorygowanymi
print("\nWyniki OLS z macierzą White'a (robust standard errors):")
print(robust_results.summary())
