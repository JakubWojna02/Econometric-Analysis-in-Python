import pandas as pd
import statsmodels.api as sm
from sklearn.preprocessing import StandardScaler

dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')


dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

data = pd.merge(dane_wejscia_powiaty, crime_ratios_powiaty, on='Nazwa', how='inner')

X = data['średnia liczba przestępstw ogółem'].values.reshape(-1, 1)
y = data['średnia ludności na 1 km2'].values

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
y_scaled = scaler.fit_transform(y.reshape(-1, 1))

y_scaled = y_scaled.flatten()

X_scaled = sm.add_constant(X_scaled)
glm_model = sm.GLM(y_scaled, X_scaled, family=sm.families.Poisson()).fit()

print(glm_model.summary())
