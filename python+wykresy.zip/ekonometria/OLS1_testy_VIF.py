import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor
from scipy.stats import shapiro

# Wczytanie danych
dane_wejscia = pd.read_excel('input_parameters1.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie zmiennych do modelu
y = crime_ratios_powiaty.iloc[:, 1]  # Zmienna zależna
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)  # Usunięcie kolumny 'Nazwa'
X = sm.add_constant(X)  # Dodanie stałej

# Dopasowanie modelu OLS
model = sm.OLS(y, X).fit()

# Testy diagnostyczne
print("1. Testy Breuscha-Pagana dla heteroskedastyczności każdej zmiennej:")
for col in X.columns:
    if col != 'const':  # Pomijamy stałą
        test_data = sm.add_constant(X[[col]])  # Dodajemy stałą do danych
        _, pvalue, _, _ = het_breuschpagan(model.resid, test_data)
        print(f"{col}: p-value = {pvalue:.4f}")

print("\n2. Współczynniki VIF (wielokolinearność):")
vif_data = pd.DataFrame()
vif_data["Variable"] = X.columns
vif_data["VIF"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
print(vif_data)

print("\n3. Test Shapiro-Wilka dla normalności reszt:")
stat, p = shapiro(model.resid)
print(f"Shapiro-Wilk Statistic: {stat:.4f}, p-value: {p:.4e}")
