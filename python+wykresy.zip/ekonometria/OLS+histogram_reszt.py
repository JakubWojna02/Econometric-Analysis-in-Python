import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Podzielenie zmiennej crime_ratios_srednie przez 10 000
crime_ratios_powiaty.iloc[:, 1] = crime_ratios_powiaty.iloc[:, 1] / 10000

# Przygotowanie zmiennych dla modelu OLS (dane z crime_ratios_srednie.xlsx)
y = crime_ratios_powiaty.iloc[:, 1]  # Zmienna zależna po podzieleniu przez 10 000
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)  # Usunięcie kolumny 'Nazwa', bo to etykieta
X = sm.add_constant(X)  # Dodanie stałej do modelu

# Dopasowanie modelu OLS
model = sm.OLS(y, X).fit()

# Obliczenie przewidywań modelu
y_pred = model.predict(X)

# Tworzenie wykresu porównawczego
plt.figure(figsize=(10, 6))
plt.scatter(y, y_pred, alpha=0.7, label='Dane')
plt.plot([y.min(), y.max()], [y.min(), y.max()], color='red', linestyle='--', label='Idealne dopasowanie')
plt.xlabel('Wartości rzeczywiste (y)')
plt.ylabel('Wartości przewidywane (y_pred)')
plt.title('Porównanie wartości rzeczywistych i przewidywanych')
plt.legend()
plt.grid(True)
plt.show()

# Tworzenie wykresu reszt
residuals = y - y_pred
plt.figure(figsize=(10, 6))
sns.histplot(residuals, kde=True, bins=30, color='blue', alpha=0.7)
plt.axvline(0, color='red', linestyle='--', label='Środek (0)')
plt.xlabel('Reszty (y - y_pred)')
plt.ylabel('Częstość')
plt.title('Histogram reszt modelu OLS')
plt.legend()
plt.grid(True)
plt.show()
