import pandas as pd
import statsmodels.api as sm

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie zmiennych dla modelu GLM
y = crime_ratios_powiaty.iloc[:, 1]  # Druga kolumna jako zmienna zależna
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)  # Usunięcie kolumny 'Nazwa', bo to etykieta
X = sm.add_constant(X)  # Dodanie stałej do modelu




model_glm = sm.GLM(y, X, family=sm.families.NegativeBinomial()).fit()


# Wyświetlenie podsumowania modelu
print(model_glm.summary())
