import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.genmod.families import Gaussian, Binomial
from statsmodels.iolib.summary2 import summary_col

# Wczytanie danych
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie zmiennych
y = crime_ratios_powiaty.iloc[:, 1]
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)
X = sm.add_constant(X)

# Standaryzacja danych
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
y_scaled = (y - y.mean()) / y.std()
X_scaled = sm.add_constant(X_scaled)

# GLMy z rodzinami Gaussian i Binomial
families = [Gaussian(), Binomial()]
glm_models = []
for family in families:
    try:
        glm_model = sm.GLM(y_scaled, X_scaled, family=family).fit()
        glm_models.append(glm_model)
    except Exception as e:
        print(f"GLM with {family.__class__.__name__} failed: {e}")

# Podsumowanie tabeli
model_names = [f"GLM ({fam.__class__.__name__})" for fam in families[:len(glm_models)]]
summary = summary_col(
    glm_models,
    model_names=model_names,
    stars=True,
    float_format="%.4f",
    info_dict={"Observations": lambda x: f"{int(x.nobs)}"}
)

print(summary.as_latex())
