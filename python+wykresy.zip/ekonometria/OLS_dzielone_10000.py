import pandas as pd
import numpy as np
import statsmodels.api as sm


# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Podzielenie zmiennej crime_ratios_srednie przez 10 000
crime_ratios_powiaty.iloc[:, 1] = crime_ratios_powiaty.iloc[:, 1] / 10000

# Przygotowanie zmiennych dla modelu OLS (dane z crime_ratios_srednie.xlsx)
y = crime_ratios_powiaty.iloc[:, 1]  # Zmienna zależna po podzieleniu przez 10 000
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)  # Usunięcie kolumny 'Nazwa', bo to etykieta
X = sm.add_constant(X)  # Dodanie stałej do modelu

# Dopasowanie modelu OLS
model = sm.OLS(y, X).fit()

# Dopasowanie modelu z odpornymi błędami standardowymi (HC3)
model_robust = sm.OLS(y, X).fit(cov_type='HC3')

# Wyświetlenie podsumowania modelu
print(model_robust.summary())
