import pandas as pd
import statsmodels.api as sm
from statsmodels.iolib.summary2 import summary_col

# Wczytanie danych
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie zmiennych
y = crime_ratios_powiaty.iloc[:, 1]  # Zmienna zależna
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)
X = sm.add_constant(X)

# Model OLS
model_ols = sm.OLS(y, X).fit()

# Model WLS
residuals = model_ols.resid
variance_estimation = residuals**2
weights = 1 / (variance_estimation + 1e-5)
model_wls = sm.WLS(y, X, weights=weights).fit()

# Model OLS z macierzą White'a (HC3)
model_white = sm.OLS(y, X).fit(cov_type='HC3')

# Zestawienie wyników w jednej tabeli
summary = summary_col(
    [model_ols, model_white, model_wls],
    model_names=["OLS", "White (HC3)", "WLS"],
    stars=True,
    float_format="%.4f",
    info_dict={"R-squared": lambda x: f"{x.rsquared:.4f}", "Observations": lambda x: f"{int(x.nobs)}"}
)

# Drukowanie tabeli w formacie publikacyjnym (np. dla LaTeX)
print(summary.as_latex())
