import pandas as pd
import statsmodels.api as sm
from scipy.stats import f

# 1. Wczytanie danych wejściowych
input_params = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_data = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# 2. Filtrowanie danych tylko dla "Powiaty"
input_params_powiaty = input_params[input_params['Nazwa'].str.contains('Powiat')]
crime_data_powiaty = crime_data[crime_data['Nazwa'].str.contains('Powiat')]

# 3. Przekształcenie crime_data_powiaty za pomocą pd.melt
crime_data_powiaty = pd.melt(
    crime_data_powiaty,
    id_vars=['Nazwa'],
    var_name='crime_type',
    value_name='crime_rate'  # Zmieniono "value" na "crime_rate", aby uniknąć zamieszania
)

# Debugowanie: sprawdzenie pierwszych wierszy oraz unikalnych typów przestępstw
print("First few rows of reshaped data:")
print(crime_data_powiaty.head())

print("\nUnique crime types:")
print(crime_data_powiaty['crime_type'].unique())


# 4. Definiowanie funkcji do przeprowadzenia testu Chowa
def chow_test(crime_type, crime_data, input_params):
    """
    Przeprowadza test Chowa dla danego rodzaju przestępstwa.

    Parameters:
    crime_type (str): Rodzaj przestępstwa
    crime_data (DataFrame): Dane o przestępstwach
    input_params (DataFrame): Parametry wejściowe do modelu

    Returns:
    dict: Wyniki testu Chowa, w tym wartość statystyki F i p-value
    """
    try:
        # Filtrowanie danych dla danego rodzaju przestępstwa
        crime_subset = crime_data[crime_data['crime_type'] == crime_type]

        if crime_subset.empty:
            raise ValueError(f"Brak danych dla typu przestępstwa: {crime_type}")

        # Tworzenie zmiennych niezależnych (X) oraz zmiennej zależnej (y)
        y = crime_subset['crime_rate']  # Zmienna zależna

        # Dopasowanie zmiennych wejściowych
        input_cols = input_params['param_name'].values
        # Upewnij się, że kolumny istnieją w crime_subset
        missing_cols = [col for col in input_cols if col not in crime_subset.columns]
        if missing_cols:
            raise ValueError(f"Brakujące kolumny w danych dla typu przestępstwa {crime_type}: {missing_cols}")

        X = crime_subset[input_cols]  # Wybór kolumn zgodnie z parametrami wejściowymi
        X = sm.add_constant(X)  # Dodanie stałej do modelu

        # Regresja OLS dla całego zbioru danych
        model_full = sm.OLS(y, X).fit()

        # Podział na dwie grupy na podstawie mediany jednej ze zmiennych
        split_variable = input_params['split_variable'].values[0]
        if split_variable not in crime_subset.columns:
            raise ValueError(f"Zmienna podziału '{split_variable}' nie istnieje w danych dla {crime_type}")

        median_split = crime_subset[split_variable].median()
        group_1 = crime_subset[crime_subset[split_variable] <= median_split]
        group_2 = crime_subset[crime_subset[split_variable] > median_split]

        # Regresja OLS dla grupy 1
        y1 = group_1['crime_rate']
        X1 = group_1[input_cols]
        X1 = sm.add_constant(X1)
        model_1 = sm.OLS(y1, X1).fit()

        # Regresja OLS dla grupy 2
        y2 = group_2['crime_rate']
        X2 = group_2[input_cols]
        X2 = sm.add_constant(X2)
        model_2 = sm.OLS(y2, X2).fit()

        # Obliczanie sumy kwadratów reszt
        SSR_full = sum(model_full.resid ** 2)
        SSR_1 = sum(model_1.resid ** 2)
        SSR_2 = sum(model_2.resid ** 2)

        # Liczba parametrów w modelu
        K = X.shape[1]  # Liczba zmiennych objaśniających (w tym stała)

        # Liczba obserwacji w całym zbiorze i w podzbiorach
        N = len(crime_subset)
        N1 = len(group_1)
        N2 = len(group_2)

        # Obliczenie statystyki F dla testu Chowa
        m = 2  # Liczba podgrup
        F_stat = ((SSR_full - (SSR_1 + SSR_2)) / (K * (m - 1))) / ((SSR_1 + SSR_2) / (N - m * K))

        # Obliczenie p-value
        p_value = 1 - f.cdf(F_stat, dfn=K * (m - 1), dfd=(N - m * K))

        return {
            'crime_type': crime_type,
            'F_stat': F_stat,
            'p_value': p_value,
            'reject_H0': p_value < 0.05
        }

    except Exception as e:
        print(f"Problem z typem przestępstwa '{crime_type}': {e}")
        return {
            'crime_type': crime_type,
            'F_stat': None,
            'p_value': None,
            'reject_H0': None,
            'error': str(e)
        }


# 5. Przeprowadzenie testu Chowa dla każdego rodzaju przestępstwa
crime_types = crime_data_powiaty['crime_type'].unique()
chow_results = []

for crime_type in crime_types:
    print(f"Przetwarzanie typu przestępstwa: {crime_type}...")
    result = chow_test(crime_type, crime_data_powiaty, input_params_powiaty)
    chow_results.append(result)

# 6. Konwersja wyników do DataFrame i zapis do pliku CSV
chow_results_df = pd.DataFrame(chow_results)
chow_results_df.to_csv('chow_test_results.csv', index=False)

# 7. Wyświetlenie wyników
print("\nWyniki testu Chowa:")
print(chow_results_df)
