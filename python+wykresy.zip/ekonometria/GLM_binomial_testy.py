import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson
import matplotlib.pyplot as plt

# Wczytanie danych
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie zmiennych do modelu
y = crime_ratios_powiaty.iloc[:, 1]  # Druga kolumna jako zmienna zależna
X = dane_wejscia_powiaty.drop(['Nazwa'], axis=1)  # Usunięcie kolumny 'Nazwa', bo to etykieta
X = sm.add_constant(X)  # Dodanie stałej do modelu

# Dopasowanie modelu GLM
model_glm = sm.GLM(y, X, family=sm.families.Gaussian()).fit()

# --- 1. Test na autokorelację (Durbin-Watson) ---
dw_stat = durbin_watson(model_glm.resid_response)
print(f"Durbin-Watson statistic: {dw_stat:.3f} (wartość bliska 2 wskazuje brak autokorelacji)")

# --- 2. Wizualna ocena homoskedastyczności ---
plt.figure(figsize=(10, 6))
plt.scatter(model_glm.fittedvalues, model_glm.resid_deviance, alpha=0.5)
plt.axhline(0, color='red', linestyle='--', linewidth=1)
plt.xlabel("Wartości przewidywane")
plt.ylabel("Reszty deviance")
plt.title("Wykres reszt deviance względem wartości przewidywanych")
plt.show()

# --- 3. Test na współliniowość (VIF) ---
vif_data = pd.DataFrame()
vif_data['Variable'] = X.columns
vif_data['VIF'] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]

print("\nWspółczynnik VIF (Variance Inflation Factor):")
print(vif_data)

# --- 4. Podstawowe statystyki reszt ---
print("\nPodstawowe statystyki reszt:")
print(f"Średnia reszt deviance: {np.mean(model_glm.resid_deviance):.3f}")
print(f"Odchylenie standardowe reszt deviance: {np.std(model_glm.resid_deviance):.3f}")
