import statsmodels.api as sm
import pandas as pd

# Wczytanie danych z pliku
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Przygotowanie danych do regresji
# Zmienna zależna
y = crime_ratios_powiaty['średnia liczba przestępstw ogółem']

# Zmienne objaśniające
X = dane_wejscia_powiaty[['średnia ludności na 1 km2', 'średnia liczba ludności w tysiącach',
                          'średnia liczba ludności w tysiącach mężczyźni', 'średnia ludność w tysiącach kobiety',
                          'średni wskaźnik urbanizacji w %', 'średnia liczba bezrobotnych osób']]

# Dodanie stałej do zmiennych objaśniających
X = sm.add_constant(X)

# Możesz stworzyć wagi na podstawie jakiegoś kryterium, np. odwrotności zmienności reszt
# Tutaj jako przykład możemy użyć odwrotności liczby bezrobotnych osób, aby dać większe wagi powiatom z mniejszą liczbą bezrobotnych
wagi = 1 / (dane_wejscia_powiaty['średnia liczba bezrobotnych osób'] + 1)  # Unikamy dzielenia przez zero

# Model WLS (Weighted Least Squares)
model_wls = sm.WLS(y, X, weights=wagi)
wyniki_wls = model_wls.fit()

# Wyświetlenie wyników regresji z wagami
print(wyniki_wls.summary())
