import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan, het_goldfeldquandt
import matplotlib.pyplot as plt
from scipy.stats import shapiro

# Wczytanie danych z pliku 'input_parameters.xlsx' i 'crime_ratios_srednie.xlsx'
dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')

# Filtrowanie danych dla powiatów
dane_wejscia_powiaty = dane_wejscia[dane_wejscia['Nazwa'].str.contains('Powiat')]
crime_ratios_powiaty = crime_ratios[crime_ratios['Nazwa'].str.contains('Powiat')]

# Zakładając, że dane z obu plików odpowiadają sobie w wierszach, np. w pliku 'input_parameters.xlsx'
# mamy dane dla powiatów, a w pliku 'crime_ratios_srednie.xlsx' są średnie liczby przestępstw,
# możemy połączyć oba zbiory danych na podstawie indeksu (jeśli odpowiadają sobie wierszami).
dane = dane_wejscia.copy()  # Tworzymy kopię danych wejściowych
dane['średnia liczba przestępstw ogółem'] = crime_ratios['średnia liczba przestępstw ogółem']

# Wybór zmiennych niezależnych (X) oraz zmiennej zależnej (Y)
X = dane[['średnia ludności na 1 km2', 'średnia liczba ludności w tysiącach',
          'średnia liczba ludności w tysiącach mężczyźni', 'średnia ludność w tysiącach kobiety',
          'średni wskaźnik urbanizacji w %', 'średnia liczba bezrobotnych osób',
          'średnia liczba bezrobotnych mężczyzn', 'średnia liczba bezrobotnych kobiet',
          'Średni dochód budżetu powiatów na mieszkańca', 'średnie dochody budżetów powiatu']]  # Zmienne niezależne
y = dane['średnia liczba przestępstw ogółem']  # Zmienna zależna

# Dodaj wyraz wolny (stałą) do modelu
X = sm.add_constant(X)

# Funkcja do regresji krokowej
def stepwise_selection(X, y, threshold_in=0.05, threshold_out=0.10, verbose=True):
    initial_features = X.columns.tolist()
    best_features = []

    while len(initial_features) > 0:
        changed = False
        # Dodaj do modelu zmienną, która ma najlepszy p-value
        model = sm.OLS(y, X[best_features + initial_features]).fit()
        p_values = model.pvalues.iloc[1:]  # Pomijamy wyraz wolny (stałą)
        max_p_value = p_values.max()

        if max_p_value >= threshold_in:
            # Zmienna ma p-value powyżej progu, więc dodajemy ją do modelu
            worst_feature = p_values.idxmax()
            if worst_feature in initial_features:  # Sprawdź, czy zmienna jest w initial_features
                initial_features.remove(worst_feature)
                best_features.append(worst_feature)
                changed = True
                if verbose:
                    print(f'Dodano {worst_feature} do modelu, p-value: {max_p_value:.4f}')

        # Sprawdź zmienne w modelu, które mają p-value powyżej threshold_out, aby je usunąć
        model = sm.OLS(y, X[best_features]).fit()
        p_values = model.pvalues.iloc[1:]
        for feature in p_values.index:
            if p_values[feature] > threshold_out:
                best_features.remove(feature)
                changed = True
                if verbose:
                    print(f'Usunięto {feature} z modelu, p-value: {p_values[feature]:.4f}')

        if not changed:
            break

    return best_features

# Wywołanie funkcji regresji krokowej
best_features = stepwise_selection(X, y)

# Dopasowanie modelu na wybranych zmiennych
X_best = sm.add_constant(X[best_features])
model = sm.OLS(y, X_best).fit()

# Wyniki regresji
print(model.summary())

# Test Breuscha-Pagana (heteroskedastyczność)
bp_test = het_breuschpagan(model.resid, model.model.exog)
print("Breusch-Pagan Test:")
print(f"LM statistic: {bp_test[0]:.4f}")
print(f"LM p-value: {bp_test[1]:.4e}")
print(f"F statistic: {bp_test[2]:.4f}")
print(f"F p-value: {bp_test[3]:.4e}")
print("\n")

# Test Goldfelda-Quandta (heteroskedastyczność)
gq_test = het_goldfeldquandt(y, X_best)
print("Goldfeld-Quandt Test:")
print(f"F statistic: {gq_test[0]:.4f}")
print(f"p-value: {gq_test[1]:.4e}")
print("\n")

# Wykres wartości Cooka
influence = model.get_influence()
cooks_d, _ = influence.cooks_distance

plt.figure(figsize=(10, 6))
plt.stem(np.arange(len(cooks_d)), cooks_d, markerfmt=",", basefmt=" ")
plt.title("Wykres wartości Cooka")
plt.xlabel("Indeks obserwacji")
plt.ylabel("Cook's Distance")
plt.axhline(4 / len(cooks_d), color='red', linestyle='--', label="4/n próg")
plt.legend()
plt.show()

# Test Shapiro-Wilka (normalność reszt)
shapiro_test_stat, shapiro_p_value = shapiro(model.resid)
print(f"Shapiro-Wilk Test:\nStatistic: {shapiro_test_stat:.4f}, p-value: {shapiro_p_value:.4e}")

# Wykres QQ-plot
plt.figure(figsize=(10, 6))
sm.qqplot(model.resid, line='45', fit=True)
plt.title("QQ-Plot: Analiza normalności (Shapiro-Wilk)")
plt.show()
