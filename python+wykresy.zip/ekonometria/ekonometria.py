import pandas as pd


df = pd.read_excel('crime_ratios_srednie.xlsx')

# Filter out voivodeships and country-level data (they typically start with uppercase letters)
powiaty_df = df[df['Nazwa'].str.contains('Powiat', case=True, na=False)]


top_10 = powiaty_df.nlargest(10, 'średnia liczba przestępstw ogółem')
bottom_10 = powiaty_df.nsmallest(10, 'średnia liczba przestępstw ogółem')


def format_table(df, title):
    result_df = df[['Nazwa', 'średnia liczba przestępstw ogółem']].copy()
    result_df['średnia liczba przestępstw ogółem'] = result_df['średnia liczba przestępstw ogółem'].round(1)
    result_df.columns = ['Powiat', 'Średnia liczba przestępstw']
    result_df = result_df.reset_index(drop=True)
    result_df.index = result_df.index + 1  # Start index from 1
    print(title)
    print(result_df.to_string())
    print("\
")

format_table(top_10, "10 powiatów z najwyższą przestępczością:")
format_table(bottom_10, "10 powiatów z najniższą przestępczością:")