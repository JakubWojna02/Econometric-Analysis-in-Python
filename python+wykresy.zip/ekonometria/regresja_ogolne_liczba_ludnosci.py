# Import necessary libraries
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt

dane_wejscia = pd.read_excel('input_parameters.xlsx', sheet_name='TABLICA', engine='openpyxl')
crime_ratios = pd.read_excel('crime_ratios_srednie.xlsx', engine='openpyxl')


data = pd.merge(dane_wejscia, crime_ratios, on='Nazwa', how='inner')

X = data['średnia ludności na 1 km2']
y = data['średnia liczba przestępstw ogółem']

# dodaj stałą
X = sm.add_constant(X)

model = sm.OLS(y, X).fit()

# Print the summary of the regression
print(model.summary())

# Plot the regression line
plt.scatter(data['średnia ludności na 1 km2'], data['średnia liczba przestępstw ogółem'], color='blue', label='Data')
plt.plot(data['średnia ludności na 1 km2'], model.predict(X), color='red', label='Regression Line')
plt.xlabel('średnia ludności na 1 km²')
plt.ylabel('średnia liczba przestępstw ogółem')
plt.title('Analiza regresji liniowej')
plt.legend()
plt.show()
