import pandas as pd
from scipy.stats import pearsonr, linregress
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# Wczytanie danych
df = pd.read_excel('crime_ratios_srednie.xlsx')

# Filtruj tylko powiaty
powiaty_df = df[df['Nazwa'].str.contains('Powiat', case=False)]

# Skalowanie danych
powiaty_df['scaled_ogolem'] = powiaty_df['średnia liczba przestępstw ogółem'] / 10000
powiaty_df['scaled_kryminalne'] = powiaty_df['średnia liczba przestępstw o charakterze kryminalnym'] / 10000

# Obliczenie korelacji i p-value
correlation, p_value = pearsonr(powiaty_df['scaled_ogolem'], powiaty_df['scaled_kryminalne'])

# Obliczanie regresji liniowej (slope i intercept)
slope, intercept, r_value, p_value_regression, std_err = linregress(powiaty_df['scaled_ogolem'], powiaty_df['scaled_kryminalne'])

# Wartość R-squared
r_squared = r_value ** 2

# Tworzenie wykresu
fig, ax = plt.subplots(figsize=(12, 8))

# Wykres rozrzutu - zmieniono kolor na niebieski
ax.scatter(powiaty_df['scaled_ogolem'], powiaty_df['scaled_kryminalne'],
           color='blue', alpha=0.5, s=50, zorder=2)

# Definiowanie linii regresji
xseq = np.linspace(powiaty_df['scaled_ogolem'].min(), powiaty_df['scaled_ogolem'].max(), num=len(powiaty_df))
yseq = intercept + slope * xseq

# Rysowanie linii regresji
ax.plot(xseq, yseq, color="darkred", lw=2, zorder=1, linestyle="--")

# Dodawanie tekstu z wynikami korelacji
correlation_text = f'Współczynnik korelacji: {correlation:.4f}'
p_value_text = f'P-value: {p_value:.10f}'
ci_text = f'Przedział ufności 95%: ({correlation:.4f}, {correlation:.4f})'  # Zamiast przedziału ufności, tu dajemy te same wartości korelacji, jeśli to jest to, co chcesz.

ax.text(0.05, 0.80, correlation_text, transform=ax.transAxes, fontsize=14, weight='bold', horizontalalignment='left')
ax.text(0.05, 0.75, p_value_text, transform=ax.transAxes, fontsize=14, weight='bold', horizontalalignment='left')
ax.text(0.05, 0.70, ci_text, transform=ax.transAxes, fontsize=14, weight='bold', horizontalalignment='left')

# Dostosowanie wyglądu wykresu
ax.set_title('Korelacja między przestępstwami ogółem a kryminalnymi', fontsize=14, style='italic')
ax.set_xlabel('Średnia liczba przestępstw ogółem (x10,000)', fontsize=12)
ax.set_ylabel('Średnia liczba przestępstw kryminalnych (x10,000)', fontsize=12)

# Usuwanie spines
ax.spines[['right', 'top', 'left', 'bottom']].set_visible(False)

# Siatka
ax.grid(True, linestyle='--', alpha=0.3)

# Dostosowanie układu
plt.tight_layout()

# Pokazanie wykresu
plt.show()

# Wyniki szczegółowe
print("Szczegółowe wyniki testu korelacji Pearsona:")
print(f"Współczynnik korelacji: {correlation:.4f}")
print(f"P-value: {p_value:.10f}")
print(f"Przedział ufności 95%: ({correlation:.6f}, {correlation:.6f})")
